﻿using System;

Console.OutputEncoding = System.Text.Encoding.UTF8;
int sum = 0;
Console.WriteLine("Введіть масив на 25 елементів використовуючи цілі числа в діапазоні від -25 до 25 ");
int[] n = Console.ReadLine().Split().Select(int.Parse).ToArray();

Array.Sort(n);
Array.Reverse(n);
Console.WriteLine($"Відсортований масив за спаданням: {string.Join(" ", n)}");

for (int i = 0; i < n.Length; i++)
{
    if (n[i] %2 == 0)
    {
        sum += n[i];
    }
}

Console.WriteLine($"Сума парних елементів масиву {sum}");